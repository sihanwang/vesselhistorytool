@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.vesseltracker.com/")
package com.thomsonreuters.ce.vtclient.history.jdk;
